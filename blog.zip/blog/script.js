// script.js

// Dummy data for courses with discounts
const discountedCourses = [
    { title: "Introduction to AI", price: 50, discount: 20 },
    { title: "Data Science Fundamentals", price: 100, discount: 30 },
    { title: "Web Development 101", price: 80, discount: 25 }
  ];
  
  // Function to display discounted courses on the homepage
  function displayDiscountedCourses() {
    const coursesContainer = document.getElementById('discounted-courses');
    
    discountedCourses.forEach(course => {
      const courseElement = document.createElement('div');
      courseElement.classList.add('course-card');
      courseElement.innerHTML = `
        <h3>${course.title}</h3>
        <p>Original Price: $${course.price}</p>
        <p>Discount: ${course.discount}%</p>
        <p>Price After Discount: $${(course.price - (course.price * course.discount / 100)).toFixed(2)}</p>
        <button onclick="redirectToCoursePage('${course.title}')">View Course</button>
      `;
      coursesContainer.appendChild(courseElement);
    });
  }
  
  // Redirect to course page (dummy)
  function redirectToCoursePage(courseTitle) {
    window.location.href = `/courses/${courseTitle.replace(/\s+/g, '-').toLowerCase()}`;
  }
  
  // Initialize homepage with discounted courses
  document.addEventListener('DOMContentLoaded', displayDiscountedCourses);
  